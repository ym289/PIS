import React, { useEffect, useState } from "react";
import NavBar from "../common/NavBar";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faChevronCircleLeft,
  faExclamationCircle,
} from "@fortawesome/free-solid-svg-icons";
import { Formik } from "formik";
import * as Yup from "yup";
import { Form } from "react-bootstrap";
import { Separator, TextField } from "@fluentui/react";
import { Spinner } from "@fluentui/react/lib/Spinner";
import { PrimaryButton, Label } from "@fluentui/react";
import "../../scss/AddPatient.css";
import { faTimes } from "@fortawesome/free-solid-svg-icons";
import DataService from "../../service/DataService";
import AuthenticationService from "../../service/AuthenticationService";
import { useHistory } from "react-router-dom";
import { IconButton, Stack } from "office-ui-fabric-react";
import { PageHeaderBreadCrumb } from "../common/PageHeaderBreadCrumb";

const AddExistingPatient = () => {
  const [mobileNumber, setMobileNumber] = useState("");

  const history = useHistory();

  const cancelAddPatient = () => {
    let user = AuthenticationService.getCurrentUser();
    if (user.roles.includes("ROLE_ADMIN")) {
      history.push("/patientlist");
    } else {
      history.push("/studylist");
    }
  };
  const CallAddPatientApi = (mobileNumber) => {
    let dto = {
      mobileNumber: mobileNumber,
    };
    DataService.AddExistingPatient(dto)
      .then((response) => response.data)
      .then((data) => {
        alert("patietn Added successfully");
        history.push("/studylist");
      });
  };
  return (
    <>
      <NavBar />
      <Stack horizontal horizontalAlign="space-between">
        <div style={{ width: "70vh" }}>
          <PageHeaderBreadCrumb
            header="Add Existing Patient"
            isPatientList={false}
            subtext={false}
          />
        </div>
        <Stack horizontal>
          <IconButton
            iconProps={{ iconName: "Cancel" }}
            onClick={cancelAddPatient}
          />
        </Stack>
      </Stack>
      <Separator />

      <div className="form-2">
        <Formik
          initialValues={{
            mobileNumber: mobileNumber,
          }}
          enableReinitialize={true}
          onSubmit={(values, { setSubmitting }) => {
            CallAddPatientApi(values.mobileNumber);
          }}
          validationSchema={Yup.object().shape({
            mobileNumber: Yup.string()
              .required("This field cannot be left blank")
              .max(10, "Mobile Number cannot be greater than 10 characters.")
              .min(10, "Mobile Number cannot be lesser than 10 characters."),
          })}
        >
          {(props) => {
            const {
              values,
              touched,
              errors,
              isSubmitting,
              handleChange,
              handleBlur,
              handleSubmit,
            } = props;
            return (
              <Form onSubmit={handleSubmit}>
                <div>
                  <div>
                    <div className="textfield-label">
                      <Label required>Mobile Number</Label>
                    </div>
                    <TextField
                      // label="First Name"
                      autoComplete="off"
                      value={values.mobileNumber}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      name="mobileNumber"
                      placeholder="e.g. 9999999999"
                      maxLength={10}

                      // errorMessage={touched.firstname && errors.firstname}
                      // required
                    />
                    {touched.mobileNumber && errors.mobileNumber && (
                      <div className="error">
                        <FontAwesomeIcon
                          icon={faExclamationCircle}
                          style={{ marginRight: 4 }}
                        />
                        {errors.mobileNumber}
                      </div>
                    )}
                  </div>
                </div>
                <div className="go-back-or-continue sticky-footer-for-big-form">
                  {/* <div className="go-back" onClick={Goback}>
                    <FontAwesomeIcon
                      icon={faChevronCircleLeft}
                      style={{ marginRight: 3 }}
                    />
                    Go Back
                  </div> */}
                  <div>
                    <PrimaryButton className="class" type="submit">
                      Add
                    </PrimaryButton>
                  </div>
                </div>
              </Form>
            );
          }}
        </Formik>
      </div>
    </>
  );
};

export default AddExistingPatient;
