package com.sptc.pis.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sptc.pis.dto.StudylistDto;
import com.sptc.pis.model.Studylist;
import com.sptc.pis.repository.StudyTreatmentsRepository;
import com.sptc.pis.repository.StudylistRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class StudylistService {

	
	@Autowired
	private StudylistRepository studylistRepository;

	@Autowired
	private StudyTreatmentsRepository studyTreatmentsRepository;
	
	
	public boolean updateDignosis(StudylistDto studylistDto) {
		
		try {
		Studylist wl = studylistRepository.findByMobileNumberAndTreatmentDate(studylistDto.getMobileNumber(), studylistDto.getTreatmentDate());
		if(wl == null) {
			log.info("wl is null");
		}
		log.info("mobile is :{}",studylistDto.getMobileNumber());
		log.info("date is :{}",studylistDto.getTreatmentDate());

		log.info("dignosis is :{}",studylistDto.getDignosis());
		wl.setDignosis(studylistDto.getDignosis());
		studylistRepository.save(wl);
		return true;
		}catch(Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	
	public boolean deleteStudy(Long studyId) {
		try {
		log.info("Deleting study with id :{}",studyId);
		studyTreatmentsRepository.deleteAllByStudyId(studyId);
		studylistRepository.deleteById(studyId);
		return true;
		}
		catch(Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	
}
