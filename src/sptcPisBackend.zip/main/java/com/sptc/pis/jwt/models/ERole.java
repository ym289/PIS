package com.sptc.pis.jwt.models;

public enum ERole {
	ROLE_HOSPITAL_USER,
    ROLE_ADMIN
}
